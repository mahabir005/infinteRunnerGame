# C37-CAMERA.x
Modified Trex Game to use camera.x as trex.x